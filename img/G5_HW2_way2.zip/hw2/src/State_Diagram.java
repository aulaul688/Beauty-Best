public class State_Diagram {
    Layout_Algorithm l ;
    public void setalgo (Layout_Algorithm algo){
        this.l = algo;
    }
    public String getAlgo(){
        return l.getName();
    }
}
