public class Force_Based_Layout extends Layout_Algorithm {
    public String getName(){
        return "Force_Based";
    }
}
