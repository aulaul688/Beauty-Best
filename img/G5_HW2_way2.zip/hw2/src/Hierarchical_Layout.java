public class Hierarchical_Layout extends Layout_Algorithm {
    public String getName(){
        return "Hierarchical";
    }
}
