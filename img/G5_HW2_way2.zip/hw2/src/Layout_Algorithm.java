public abstract class Layout_Algorithm {
    public static void draw(State_Diagram d){
        System.out.println(d.getAlgo());
    }
    public abstract String getName();

}
