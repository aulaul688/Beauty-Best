public class Orthoronal_Layout extends Layout_Algorithm {
    public String getName(){
        return "Orthoronal";
    }
}
