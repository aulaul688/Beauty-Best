public class Edit_Diagram_Controller {
    public static void main(String[] args) {
        State_Diagram d = new State_Diagram();
        d.setalgo(new Force_Based_Layout());
        Layout_Algorithm.draw(d);

        d.setalgo(new Orthoronal_Layout());
        Layout_Algorithm.draw(d);

        d.setalgo(new Hierarchical_Layout());
        Layout_Algorithm.draw(d);

    }
}
